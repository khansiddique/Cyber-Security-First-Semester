public class Refactoring {
    int a;
    int b;
    int c;
    
    public void f() {
        if (this.a == 0) {
            this.b = 4;
            this.c = 3;
        }
        if (this.c == 1) {
            this.b = 4;
            this.c = 3;
        }
    }
    
    public Refactoring Refactoring$() {
        this.jif$init();
        {  }
        return this;
    }
    
    public static final String jlc$CompilerVersion$jif = "3.5.0";
    public static final long jlc$SourceLastModified$jif = 1479823978000L;
    public static final String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAK1ZD3BUxRnfu/wjIUAIBEFCCCHgBCSnVHFsRIGEmNDTZJJI" +
       "NYwcL+/2kgfv3nu8t5ccoViso6C0mRECwlQcrdoRS8H+cSwVrbWtQtVObZ1W" +
       "7aCO02ltKVbt2NZpkX7f7vt/D7Wd3sztvtvd79vv72+/fXf4DCmxTDJno5Jp" +
       "ZlsMajWvUTLdkmnRdLeubumDoZT80QMvpvffZLwZJ6X9ZIJi3aBZUoYmSbmU" +
       "Y0O6qbAtjFQlN0rDUiLHFDWRVCzWkiQTZV2zmCkpGrM2k1tILEmqFBiRNKZI" +
       "jKbbTT3LyLykARsNqjpL0DxLGJIpZRNclER3qypZFnAq5aMOkwmGqQ8raWoy" +
       "MjcJgturVWmAqoluey6Jv1ryJql32Nv6CeU4Z6Hd3sWJ8XvWV323iEzpJ1MU" +
       "rZdJTJFbdY2BPP2kMkuzA9S0VqbTNN1PpmqUpnupqUiqMgoLda2fVFvKoCax" +
       "nEmtHmrp6jAurLZyBoiIezqDSVIpTJKTmW466pRmFKqmnV8lGVUatBiZ4ZlF" +
       "qNeO42CLCjAnNTOSTB2S4k2KlkZbhChcHRu/AAuAtCxLwV/uVsWaBAOkWnhO" +
       "lbTBRC8zFW0QlpboOYYGvvC8TFvQEZK8SRqkKUZmhtd1iylYVc4NgSSM1ISX" +
       "cU7gpQtDXvL558z1V41t1Tq0OJc5TWUV5Z8ARHUhoh6aoSbVZCoIKxcl90kz" +
       "ntoZJwQW14QWizVPfOn9FRfXPXNCrJkdsaZrYCOVWUp+aGDyy7WtTVcWiRDU" +
       "LQWdH9CcB3+3PdOSNyCxZrgccbLZmXym57mbtj9KT8dJRScplXU1l4U4mirr" +
       "WUNRqXkt1aiJKdJJyqmWbuXznaQMnpOKRsVoVyZjUdZJilU+VKrz32CiDLBA" +
       "E5XBs6JldOfZkNgQf84bhJAy+JKZ8I35+jJGliWG9CxNDFF1E4WMlLKGSq0l" +
       "kGZLliZMCnEHoQsxkujxnpth1vifKfMoU9VILAbmqg0nqwpx3qGrkNApeTy3" +
       "avX7R1IvxN3gtbVhZKKPJ4nFOK/pGNbC7GC0TZB+AEuVTb03r9mws6EI/G2M" +
       "FKPasLQhAH+tXo52criSIVB+fY2xYezy2VfFSUk/wJjVBhvmVNbdukrPaZDu" +
       "092hHgpIoHH8icTAMkPmNIxcUIBeArWAzPSYINlsCM7GcIpEiTllxzt/P7pv" +
       "m+4lCyONBTlcSIk52BA2vqnLNA2o5rFfVC89nnpqW2OcFENig24MNEOcqAvv" +
       "EcjFFgfXUJcSUC+jm1lJxSnHKhVsyNRHvBEeFZOxqRYBgh4NCcghcXmvcfDV" +
       "X/zpc3ES99Bziu806qWsxZexyGwKz82pXoD0mZTCulP7u/fsPbNjHY8OWDE/" +
       "asNGbFshU+FMAgvefmLza2++8dArcS+iGBxYuQFVkfNcl6nn4BOD78f4xbTD" +
       "AewBfFvtlK93c97AnRd6skH2q4BAILrVeIOW1dNKRpEGVIrh/O8pCy59/C9j" +
       "VcLdKowI45nk4k9n4I3PWkW2v7D+H3WcTUzG08ezn7dMQNo0j/NK05S2oBz5" +
       "W38158Dz0kEARwAkSxmlHGMItwfhDryE22IxbxOhuaXY1EPWhidhu9lebvIc" +
       "gQNcEad7Sp7xQUPCaG97i/u+AsIxA0WLIkM5UluQWq3uLOYXHqKDzuI5BYs7" +
       "vWnMjAvCMtj7F99cn/6gvmEdT4eJaWrJpmI4QQaQW2EpAIJgbprmWQyHPdPX" +
       "gPncysWUNEsFr4vM7+OTq/OGiefmsGRyP3GrNOQxYF0xurEgSslX7Nph6vPv" +
       "Wha3DTlZBByYbhaxm5i/x9lpBrbT81CzpQVi1RtyvepAzecx7vlGjmyexT35" +
       "UvLBmnuOV39r90pxcs4NUhSsvuqS1jtSl33nJZ4lGEV1YZP2UAlQXtg8JX9w" +
       "3+u05/KP3hVZrY9o4WrPAKiXFUPCis9+wkLR5FxQj5Ug1cyC2LHZL/va/UfP" +
       "vNG9gge8z0t4nBdUlHYYuIAkHtuC54YrT3OfbrgipeT1M365uPb4TXf6zRQi" +
       "8K0eO3Rv2V8v/uh+rrYbK/NDseISfGK8YHulkJcDSsBBfiH9frqg5tQrJ4Y7" +
       "3hXihuMgiuKapdOffmfmrK22Z3HD1fau2HVGOvuLcGnwnF3fnHz2R2U9P/c5" +
       "m3sQTDDCFwp/YrvKc0AXMF4QZc9VOmN61mfV5fNf39hy9uXvO1nS7lqlKahg" +
       "iNKvZumiJ2eN/W57l8NjjVC126dqjxi6DJumPM+ytXxkuYUQEqpGOiRrCI6c" +
       "V9Xf9u89tahOGNx3JNnzP2y7fe++HzxxmShYKiGJq65ZQYhAR2S+QmyH7TpP" +
       "pKaASBFD13tkGzynNblOKxwS/UyOzEVYqwWKpna8xHiFgjy6/A+7P94MhUJR" +
       "P5k8JFmdGpy+eGeCqxnCr/uLkam+lOO4huWC6i99woV+aLP+xOF7L2y9+jTP" +
       "Zq8qQeq5+cKicq3kK5iWPpr9MN5Q+rM4KYO6jldrcD9dK6k5LAj64bpltdqD" +
       "STIpMB+8Ool7QotbddWGKyLftuF6yCtm4RlX43NFCNFL0edL4AuhQjrsfp4f" +
       "0WOEP6icZB5vG7G5yHfUNjESk6zAkcbBmqbFhejhRw4faak89DDPxXLuBfAJ" +
       "s4+vCUjh/BYCTgoKuNAWbGWUgCI/XIKKKIIFfgIbUJaLboVLOREpF9gUK+x+" +
       "YYASdLwoCh1W5wFQNEn14cPoWzWzGs/0TwtfLDhWGIgTi4M4UcDDjxTv1SqP" +
       "vXbyvbMeUjBStEofADaLogRqU6yNOQ0KrGHqk2n12NuPj7z4UpOI6bS9xgft" +
       "HMTyKFxzULgofn75utr3vPPPpg/PhJDsxgC4FPGxLXbSb3VUCA+WrAQEpwXD" +
       "Zb2MZjJUy3tQk+N7fdWDo1whQnlDhSkPqmQV1EmEKd05fte55rHxuO8FyPyC" +
       "dxB+GvESRISsjWsmmfdJu3CK9j8e3fbkI9t2CHyuDl7nV2u57Ld/c/bF5v1v" +
       "nYy4lRZBlcnvLjHfyZALB7XwIw/bUT5yixjB9tZI3+DQbdjcgc2dPstmgsmI" +
       "dR8cHGTA7rsi0OIgNhqggvDu5iCHGTZlKopDVDqHCXoDSYndN+wzsVAx50QL" +
       "pnmNzWm93ff5OWL7zc8Wq+4gj8cHOekRL/geLIxHdwjbPdyTxKdCyNj18EWc" +
       "vc3ulQhjf88xthxl7Dk25fYoDlHGDhNkPzN21toUX7Z7LYid57Udj83jYmJ7" +
       "VHDG/xvg8OHDMe6Pk57xjxX641iUP7zMOhaVWcdF0D3llx7bH0cKj0M/weY5" +
       "IY7YkJ9hC1wD8g86LObric+AvkKJX2HnnO/lJkeYh74yfl+66+FLHTzey0g5" +
       "040lKh2mqo9VrOA9/XX8da5Xy1zxQFtj7bObx/5/76jw5+zo11FzQ0qFhTl0" +
       "3eGT1y6Ud0MF6NZEBa+og0QtwUqoQuzaF6iH6lw3TELzTrNdsN/ud4fBoSrK" +
       "gzzbKu2Hu+1+V9iD0e8q3v6Eud9jcwrSW0DD3djY9fM4I8XDupImES85gpk9" +
       "3YFRFOrrdn+gAEb//Kkwis1pLte7Xg6dLkyr04UXA0H2t89Ghu3afPAlrJ2J" +
       "NYxU8SsNlsjNokTOk2B+nN+cZ4N1KkZ8TvwnBFXW0kvbnj6x8Hn7ouoGI82z" +
       "Zv5vkROWLsXR+9Zcv/X9ZaKyLZFVaXQUN5kA0S5eR4rgz/urgjA3h1dpR9O/" +
       "Jj9WvsB974JNtS/gAtr5oGBuwRsJ//9VKXkT2bbrpzuqbwUh+0m5YvWZOYvh" +
       "P0flsgMawXcU+L7a/UuGC3CFwQMkVupWwL4LvG8zf00Y23igK1l27kZHn6sj" +
       "wyrG9fsPSdavhDMcAAA=");
    
    public Refactoring() { super(); }
    
    public void jif$invokeDefConstructor() { this.Refactoring$(); }
    
    private void jif$init() { a = 0; }
    
    public static final String jlc$CompilerVersion$jl = "2.7.1";
    public static final long jlc$SourceLastModified$jl = 1479823978000L;
    public static final String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAJ05W6wsWVV97zwuzAzMg4fMMAyX4TJhaOZWdz26u7igVld1" +
       "dVdXdVV1V1dVdxEY6v1+P7q6cRQ0OigGFQfERPzCRAlKYkL8MCT8qBCIicYY" +
       "/VD4MFGDmPCh/qhY1eece849986Q2EntvXuvtddee+312Hvtr/yg80Ceda4n" +
       "cbC3g7i4WewTM7/Jq1luGnig5vm66XhR/1wXeOW3PvrYH9/XeVTpPOpGQqEW" +
       "ro7HUWHWhdJ5JDRDzcxyzDBMQ+k8HpmmIZiZqwbuoUGMI6XzRO7akVqUmZmv" +
       "zDwOqhbxibxMzOw451kn03lEj6O8yEq9iLO86DzGeGqlAmXhBgDj5sUtpvOg" +
       "5ZqBkaedn+1cYToPWIFqN4hvZc5WARwpAmTb36A/5DZsZpaqm2dD7vfdyCg6" +
       "77w84vaKb9ANQjP0WmgWTnx7qvsjtenoPHHCUqBGNiAUmRvZDeoDcdnMUnSe" +
       "elWiDdLrElX3Vdt8sei87TIefwJqsF5/FEs7pOi85TLakVKddZ66tGcXdusH" +
       "7Ac/8/FoFl098myYetDy/0Az6JlLg1amZWZmpJsnAx95H/N59a1f/9TVTqdB" +
       "fssl5BOcP/mZH/70+5/5xjdPcN5+DxxO80y9eFH/kvbGv3oafx69r2XjdUmc" +
       "u60q3LHy467yp5BbddLo4ltvU2yBN8+A31j9+fYTXza/f7XzENV5UI+DMmy0" +
       "6nE9DhM3MLOpGZmZWpgG1Xm9GRn4EU51rjVtxo3Mk17OsnKzoDr3B8euB+Pj" +
       "/0ZEVkOiFdH9TduNrPisnaiFc2zXSafTudZ8nbc135UL9bWiMwCcODQBxwx8" +
       "EzBrNUwCM3/Bc60XQCAzG71rFLnREWB13r7ZQJP/98i65ekNuytXGnE9fdl0" +
       "g0bPZ3FgmNmL+ivlePLDP3rx21dvK+/paorOwxdodq5cOdJ6c6vWJ2JvhOY3" +
       "xtjY2yPPCx+Zf+xTz97X7Heyu79ddoN647L2ndss1bTURqVe1B99+V/+86uf" +
       "fyk+18Oic+Mu87h7ZKvez15eVxbrptG4j3Py77uufu3Fr79042q7V69vvEah" +
       "NvvamOAzl+e4Q81vnbmMVhZXmc7DVpyFatCCzuz8ocLJ4t15z1HgDx/bb/xR" +
       "87vSfP/bfq1GtB1t3fgF/FQbr99WxyQ52axWupdWdHRPHxKSL/7dX/4rdLXl" +
       "5MyTPXrB5QlmceuC9bTEHjnayePnm7XOTLPB+4cv8L/5uR+8/OHjTjUY777X" +
       "hDfasuVTbfiLs1/8Zvr33/3HL/3N1fPdLToPJqUWuPqR86cbQs+dT9UYVtAY" +
       "d8NJfkOMwthwLVfVArPVlP9+9D39r/3bZx472e6g6TkRXtZ5/48ncN7/5Ljz" +
       "iW9/9L+eOZK5oreO/Vwc52gn3uJN55SxLFP3LR/1J//6Hb/9F+oXG7/T2Hru" +
       "Hsyj+XaOy+scV9U97uVzx/J9l2AvtMXb6yPsLcf+B/O7PSfZhqBzXVSAr/zO" +
       "U/hPfv/I9LkutjSequ+2Ukm9YCbgl8P/uPrsg392tXNN6Tx2jH5qVEhqULa7" +
       "qjTxK8dPO5nOG+6A3xmLThzvrdu29vRlO7gw7WUrOPcOTbvFbtvXLip+K4hW" +
       "SC80X6Mundlp/a4W+ljSlo/XVzrHBnQc8syxPMJvXBDw00XninoPkfKZGzZK" +
       "Xp0GI/NTr/zKj25+5pWrFyL2u+8KmhfHnETt4xwPHSeqm1ne9VqzHEeQ//zV" +
       "l/709196+SSiPXFn/JlEZfiHf/s/37n5he996x5u9L7mbHFi4G0J3CmpJ5uv" +
       "McaOdlpz95DUT7UF0khEaxsfeFVa15uvFeEvnNbuPWiNz2jpl2mdSONKY9sP" +
       "QDeRm732/+Tee3Rf23xP4wTy4xmvGWG5kRqc7dxPeIF+48zPSc2ZrzHFG01M" +
       "OpJ5ojmuHQ2yVcebJ0eje3DR7Mobz9GYuDk/ffqffv07v/bu7zYSnnceqFrV" +
       "brbiAi22bA+Yv/SVz73j4Ve+9+mjt2pc1eZX1X9/rKXKtsW0OXy13Alxmekm" +
       "o+bF4uheTOM2g6NTtWirW0XjpOJ7Mlg8+uYZnFPY2Y/uKwQ0FutVZJXAzqNE" +
       "jBpPSBzHZ/YYFyJpRuYrajoJWWKtzOcUu93pTBcAfduqoKgcFYiux5KbxwO8" +
       "F64m+C5Y6pkRr4TRrKsLOynT5GJZSJym9OWhinM9MChoSStAVkn8zdAaVgVA" +
       "DGUDyg9FVVTGEK2qIdgFrI0FE3hYr4l5FCPzRAnyherJlbhmDD+MVgZjlloZ" +
       "ErGyHvWWiyqpLEthdsp8sEEVau5C6lgR420oaKG47XGDVMMKj1wGbC8jRJeZ" +
       "kYS8kvCD7LvLtSKBhxD3k2m2AP1+QTGTMCXH7oqlFcqjNW29hpg9s/exVc6m" +
       "XsL0iJqZzqlEWbF6MFlB6T5RyAhLEXXB+btwmi5HmSrH+4Wnz+3mWiDJIZY2" +
       "pzZzP5hX/Ww/TwMIZKsBboqwMpg1a5fno00lSxAIuZNDMu8vxEwx5us5qRlb" +
       "cMzzoL/wywOGCj0p1dYs2+eTMBWTqExS0U0XdswYKmhJZEXHuFpHk7CYhVky" +
       "8LAyY5T9OHYp85ASgkQl6zm9DmV4MEhWIUmnYSSNgqkkqsXYVWAlIFPW5GAQ" +
       "Z3APi9g1J6zHoAD7IB34iubgjj5blQCGlViB18xOAkopl9Uxxvly5HCBth6v" +
       "8NGBlHvLINFibrudVhU+WpPVcqLQI2GV+rSohE5h9N19sJV0mLUFYdGnhI0u" +
       "Du1kWRCbikGQ0aEvwf2iv0573FxH1rIoIcoIW81EJ3YGaixokoLHFF3rAdrz" +
       "D1ERK/PdUu7DS9k9SLzFRSi5sjb8hsWzuW/kqpJtcU6SxaSrTon9figXa0mX" +
       "3RUhMkvZmKG4Poa6EG9wArvHayWzdV1jlHCzD5FhqBUeSq9Hxnwl6EmwEfsB" +
       "LMKhm2WyyK7SjV/0VXdOG/P5Pg1lrdwcInW5iBKOXuVSLO0VTzSUuRuIXYnO" +
       "DhCIuwQzxibIZpwP5kFzcFd81l5aI1hz5ti+O6eVEQUhXW8+DVx5iuI1S5Bk" +
       "fwLLi4Chp0LaC/ypwgSussCjySxe5rVfenWUFE6/ci3aWsQiKlEMpoWp3YvS" +
       "XVJD6TTzWSxpwgKkVpvhqk9VNQvZhSY5Ck3zczgiORpIpqyGD6d4b62Mu9ik" +
       "lNZaD8rQcJcPJhQwBRckzas5s3SwWbfYxAioZ65ASeOutQXrrXnYg5JFCqIP" +
       "7OaeNHaqUGI1o/QzXlWIsoeCzsxOqHg2G7n6Glv4fMhStS5SYxPLZOzAC1uK" +
       "DXJ8MZzqVDJx10FQHwqAHyZV2IUDfM+x43WgC5SPgGMMrNKIYTEwRjLSkvAR" +
       "GkVJKoOcTk5Y1wbhBTvh9BSrqonukaRtbcS5Loh41wv7wbwWohntSPmeXc2q" +
       "8cQkFa5OV9ux7cAsrtuOvgkr3SKkDXBIdGgioOj44Jaj3iCV81ox6/10Rx9G" +
       "YLKJiV6orPEy4IclYOW8xnqz7YiTiQmg5uxUI3NH7JILzK5MK2QOKtjtjgws" +
       "04WuOx3X23JJSr7V+JBBFMFjjhiOLLjW1gRm7sYWWRUBjUI6OsQabzfI/RmY" +
       "wmOMYprIRHFy32DpVTKZSlTmANwowfcICuCoJ+mMQcc7CkYiH/bRCKYgXvZl" +
       "sBoS3Rkk62vxMO2NzEM0NBZLNu55AEv3EAGMxwdEhkZ9ZEQcev4EW+0wX6jD" +
       "YDZdUMXOcohsPwFBqtZqzinVzbY/4WXHNZwSDUytonR7yeoT1RgKybBeijyu" +
       "TtGhC5RdLKdqrCczlL9AxKBcyilUMtx2M0tp4lBSyHibDys5WnhYhS8Kb0ii" +
       "qB4BA7sKJ8YaNueqnM2TkIKXS3Upg5MEo+a2lmShvNzPeIPf2Hyk7/PGEic5" +
       "mcHVYtjl1inATd1G4vl0teehacZyy3pL9uoym9hCHmyGbOIMKr6SHRUi1oEy" +
       "Hu+3mqPWIeICNRok40xbj/r4IVlKbn9V7CszwQ6mXg+rYOqFe7NeQ4hYMeMw" +
       "KjkJQjO0l9R6DrOiI+RVmQp9rxACCIrmChxMJ1J/q/CgiAXLTWGP5ht0B3XL" +
       "HgLQPORIjWNCY1jOeIx2N2QjNzdHuzufWSFkvfQQ0e7rexxkZgoDNCdh0eIr" +
       "doratjk69Ao4GhtiMNtuSwrzZ0WJI/A2W0OcpWW22xh7fwENkJLX4PXGGhxW" +
       "S3dE90wOWlWgNKqA0ulm2VajAZbITUqwpvRoOysDf64TQj4eW+4MtbLURopl" +
       "Noe3Q8jZuE65sN2SVpM22xBaYUaDoALNiL6lluBMmnJVyejTaBeRkBXNDuAK" +
       "FFEe0JEQypdrgsDJXQJss4rWe9hmQcJLRUclLmQH/dCSEIu1INTZo+Wm4vqR" +
       "MAzSgFYd22XpSilDdw6aLCAjw2DEep6E98GBkXq1OyDmZcgvuvti07jBrbic" +
       "pMmUc1cZTg10Cd1YaDlCC9XhpmwNzdnowIP7oWV2u7NDXYeCs6Xd6TwdIMpy" +
       "62ArUOguw/1suE74hFYxYUwSfajwp4d9xGoBR9c7ARD33GEibdOdTCeROqpn" +
       "Lml7+wGAdYc8Ci8ccb7iEX80J0Njmuy75tTE0zrCM6BkfDXsBhwHO6WMD1wU" +
       "3cVSV2X4bs2RQwbco11vzSvpKF2aKdLVaVdPIZ9GXJlPMnTBIstutoDpLTfw" +
       "AiPTCdSgBz7CYN4A1pKgMJr4vqaSxbg74uJguIwLzTDkKb1nrKIkB3u8COFV" +
       "sIEhlsRZkumZBgNjpbP0stxKYKsncxN+4OrKGKmmwymyn1ki600Ef3DAfF0b" +
       "h6lGOqbnrHawpar+CCUIvt4w5djC5jncrXDRc4DxFl/bMV2ymKxNZdHGKWBD" +
       "0TRNUaRlU5o4VxktlhhuNUlI1Bbpbt3dbjHBYHYx7vRlZEcu2UnUh3U+lg/y" +
       "YZoDvfWusBjCkaeUvXbhBSzqBOHV66ovpHy10faVtjBFbywUk9jCCJWJ7VUq" +
       "DvaNyffobDpLfTDqg2zJe8MDLCYcNdAEtLatYrZY72myPoiMHVvRECmLDKp4" +
       "nk9sgHfmRF7bOEzy05rZaIIGSSKOdeUMW06S3YZQNHCheHNxDxVLv8sOLUMm" +
       "4v7OWUYB4Qg+n4ZLqT8JJ7TRQ6zCRJBsVpfciNzze9yox91pNRFWlJB7ch6G" +
       "ljEvIZxGvZEJWZpPoQWIz/YlEQwjCSyRIWMAOqCRSNWvou0eDlbKONCjivFm" +
       "1l7BmPFws6N2gCaukb1be2O0UCioSyw1w9NtHTT4vAjtPKSM1UifTdfYsLnV" +
       "9DjKZp3UtiuiRFy86VYCOk4IiUhneBPUhG1ksN3dIZewGuktmSQK2YMcopBl" +
       "IZzMDA/6SE67sO01JDnTXzGAbTJUPTN2nsYb+3VNG/ie9fqjiaxXOlQGS8ez" +
       "RqO6cOpgSPggYm1jookshMP6/IEF+0UsbobKkNm6BjIUDW8EedtwPpRmxBSo" +
       "K3vEzYiFOeB9ZFh79WYA912RHx4WnKNKsm6QPQJqDgtDbdbTaa+3AHbmFqG2" +
       "w60/Rx28vyNG9mjAcFrm6l2s8un5BpxFEQcEc9/cOkN4bwXdwaBLMrP1wdz3" +
       "bKQH9wLaAcM0RqWMw1BgsxkZKrLZ9w/1kmyClMZpNYAAw4G3Q7qHuN8nD8te" +
       "SjrroAeZ03V/PxCN3oIcsMpkrHZju7csdmIaL8uDSg7c2SDYQesJc1hnrJGz" +
       "QGnA1jgWMto+HDS68aRlt9+VUJfomaMUqgaT0kA9fZcJco8gIMPbotYCpkYb" +
       "okyocCKMEDvxUWhLrkguy4yoa2MTDQBof+fm/YQpzOHGHhiMv896sLjBejOw" +
       "GKFTp4RUi8eCbA7O2W0tjoS8OX15bOyvOR8cdyO2qysw26d9ZbSudtGY3Mg9" +
       "v9Iib1CPZtEwLuMpNQIPSoVU/qrRinyz6qKKXgHN/UttvI5CSupmKbKIj/UE" +
       "xFzBmX0Aysz2MMjpG8kK5YC5h8pVPkaH8JwtBMDGigyJp+Nyt8rnAIBK9MZf" +
       "g5qWJYcy1Xai0+2FyLaSFW5bOXzPCnJ7oe6am0OXGTaxsZziUBNilgtfKhN5" +
       "x8BMNR0drF5v29yqbLofgENfmUWD3NvtsynaHNcEQ60cYqE3t+APtddj6fSm" +
       "/fgxD3D7vaS5YLcA5niZPrlfP9MWz97OYhx/D55mzc/qzoUsxoWEW6dN3Lzj" +
       "1R44jkmbL/38K79rcL/Xv3qaVPpg0Xl9EScvBGZlBhdI3d9QeuclSovjo855" +
       "Au4PFl/51vQ5/bNXO/fdzp3d9TZ056Bbd2bMHsrM5g4bre/Imz15e+1vaNf0" +
       "ptN1f+G0/uzFDM55EuKS2I7Jn0dOG79xWn/6stjuncm0XwN2zB9pRefKvRMj" +
       "VeyevHp97DYnT56ltK5crO9aRFtcf42J09eAHTujovPIhceJG+eiOefl+BTz" +
       "3JkSndVF5yN3Z+A/cD0t1dxNy7gw33uS2L7eru56o7I33KiKfZMwrQuvEO99" +
       "/vrHC8c9Po7dZuK9z9966fnbyfwfp963OWqhuyR5jSV//DVgL7VFWXTe9mqs" +
       "tnD/kmhe1w5//G7R8D9ONJlbNZ0XZeMWrSyuf9is1OC96sfVUHvp+oeu956/" +
       "9RHh+mVpXE4jXik6105J1ncK6dq9hPTJ1xTSy68B++W2+Lmi87ozno9Cqe98" +
       "4Tqlfmd+8iRdXv8fML7Z1AQfAAA=");
}
